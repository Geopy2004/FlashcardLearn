final List<Map<String, dynamic>> mathFlashcards = [
  {
    "question": "What is 5 + 3?",
    "answer": "8",
  },
  {
    "question": "What is 9 - 4?",
    "answer": "5",
  },
  {
    "question": "What is 7 x 2?",
    "answer": "14",
  },
  {
    "question": "What is 16 / 4?",
    "answer": "4",
  },
  {
    "question": "What is 12 + 15?",
    "answer": "27",
  },
  {
    "question": "What is 18 - 9?",
    "answer": "9",
  },
  {
    "question": "What is 6 x 5?",
    "answer": "30",
  },
  {
    "question": "What is 81 / 9?",
    "answer": "9",
  },
  {
    "question": "What is 25 + 30?",
    "answer": "55",
  },
  {
    "question": "What is 50 - 15?",
    "answer": "35",
  },
  {
    "question": "What is 7 x 6?",
    "answer": "42",
  },
  {
    "question": "What is 64 / 8?",
    "answer": "8",
  },
  {
    "question": "What is 13 + 17?",
    "answer": "30",
  },
  {
    "question": "What is 20 - 5?",
    "answer": "15",
  },
  {
    "question": "What is 9 x 4?",
    "answer": "36",
  },
  {
    "question": "What is 72 / 9?",
    "answer": "8",
  },
  {
    "question": "What is 45 + 15?",
    "answer": "60",
  },
  {
    "question": "What is 100 - 25?",
    "answer": "75",
  },
  {
    "question": "What is 11 x 3?",
    "answer": "33",
  },
  {
    "question": "What is 99 / 11?",
    "answer": "9",
  },
  {
    "question": "What is 14 + 18?",
    "answer": "32",
  },
  {
    "question": "What is 60 - 20?",
    "answer": "40",
  },
  {
    "question": "What is 8 x 7?",
    "answer": "56",
  },
  {
    "question": "What is 56 / 7?",
    "answer": "8",
  },
  {
    "question": "What is 21 + 9?",
    "answer": "30",
  },
  {
    "question": "What is 75 - 35?",
    "answer": "40",
  },
  {
    "question": "What is 6 x 8?",
    "answer": "48",
  },
  {
    "question": "What is 48 / 6?",
    "answer": "8",
  },
  {
    "question": "What is 33 + 22?",
    "answer": "55",
  },
  {
    "question": "What is 80 - 40?",
    "answer": "40",
  },
];
