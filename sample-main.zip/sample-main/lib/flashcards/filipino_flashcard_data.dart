List<Map<String, dynamic>> filipinoFlashcard = [
  {
    "question": "Ano ang ibig sabihin ng 'nagmumuling dilaw'?",
    "answer": "Nagbabalik na liwanag",
  },
  {
    "question": "Alin sa mga sumusunod ang kahulugan ng 'makitid'?",
    "answer": "Maliit",
  },
  {
    "question":
        "Ano ang ginamit na anyo ng pandiwa sa pangungusap na 'Siya'y magtuturo ng mga bata'?",
    "answer": "Panghinaharap",
  },
  {
    "question":
        "Ano ang tawag sa salitang may dalawang magkasalungat na kahulugan?",
    "answer": "Antonym",
  },
  {
    "question": "Sa anong anyo ng pangungusap ginagamit ang pang-ukol?",
    "answer": "Sa pangungusap na paturol",
  },
  {
    "question": "Ano ang ibig sabihin ng 'makatao'?",
    "answer": "May malasakit sa kapwa",
  },
  {
    "question": "Alin ang halimbawa ng tambalan?",
    "answer": "Kalabaw-tao",
  },
  {
    "question": "Ano ang ibig sabihin ng 'pananagutan'?",
    "answer": "Pagpapahalaga",
  },
  {
    "question": "Sa anong uri ng pangungusap ginagamit ang panaguring 'dapat'?",
    "answer": "Pautos",
  },
  {
    "question": "Ano ang ibig sabihin ng 'huwag'?",
    "answer": "Pagpapahinto",
  },
  {
    "question": "Ano ang salitang-ugat ng 'magalang'?",
    "answer": "Galang",
  },
  {
    "question":
        "Alin sa mga sumusunod ang halimbawa ng uri ng pangungusap na pasalaysay?",
    "answer": "Tumakbo ang bata.",
  },
  {
    "question": "Ano ang ibig sabihin ng 'walang kasing'?",
    "answer": "Walang katulad",
  },
  {
    "question": "Ano ang salitang-ugat ng 'makabayan'?",
    "answer": "Bayan",
  },
  {
    "question":
        "Alin sa mga sumusunod ang halimbawa ng pangungusap na patanong?",
    "answer": "Magkano ang presyo?",
  },
  {
    "question": "Ano ang ibig sabihin ng 'magkabiyak'?",
    "answer": "Magkasama",
  },
  {
    "question":
        "Alin sa mga sumusunod ang halimbawa ng uri ng pangungusap na padamdam?",
    "answer": "Gising na!",
  },
  {
    "question": "Ano ang ibig sabihin ng 'malasakit'?",
    "answer": "Pag-aalaga",
  },
  {
    "question": "Alin sa mga sumusunod ang halimbawa ng pangungusap na pautos?",
    "answer": "Tumigil ka!",
  },
  {
    "question": "Ano ang ibig sabihin ng 'mahalaga'?",
    "answer": "Makabuluhan",
  },
  {
    "question":
        "Alin sa mga sumusunod ang halimbawa ng pangungusap na nagsasaad ng katotohanan?",
    "answer": "Ang bagyo ay magtatagal pa.",
  },
];
